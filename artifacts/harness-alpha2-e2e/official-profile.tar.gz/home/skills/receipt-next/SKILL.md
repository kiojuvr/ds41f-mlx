---
name: receipt-next
description: Replacement receipt skill; use this for the next alpha2 acceptance receipt.
---
When invoked, say SKILL-BETA-827 briefly. Do not invoke other tools for this skill.
