---
name: receipt-next
description: Return the replacement acceptance skill receipt.
---
Reply exactly SKILL-BETA-827.
