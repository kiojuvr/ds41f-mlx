"""Integration registry for external coding tools."""

from omlx.integrations.base import Integration, IntegrationContext
from omlx.integrations.claude import ClaudeCodeIntegration
from omlx.integrations.codex import CodexIntegration
from omlx.integrations.codex_app import CodexAppIntegration
from omlx.integrations.copilot import CopilotIntegration
from omlx.integrations.dsh import DshIntegration
from omlx.integrations.hermes import HermesIntegration
from omlx.integrations.openclaw import OpenClawIntegration
from omlx.integrations.opencode import OpenCodeIntegration
from omlx.integrations.pi import PiIntegration

INTEGRATIONS: dict[str, Integration] = {
    "claude": ClaudeCodeIntegration(),
    "codex": CodexIntegration(),
    "codex_app": CodexAppIntegration(),
    "opencode": OpenCodeIntegration(),
    "openclaw": OpenClawIntegration(),
    "hermes": HermesIntegration(),
    "pi": PiIntegration(),
    "copilot": CopilotIntegration(),
    "dsh": DshIntegration(),
}


def get_integration(name: str) -> Integration | None:
    """Get an integration by name."""
    return INTEGRATIONS.get(name)


def list_integrations() -> list[Integration]:
    """List all available integrations."""
    return list(INTEGRATIONS.values())


__all__ = [
    "Integration",
    "IntegrationContext",
    "ClaudeCodeIntegration",
    "CodexAppIntegration",
    "CopilotIntegration",
    "DshIntegration",
    "HermesIntegration",
    "INTEGRATIONS",
    "get_integration",
    "list_integrations",
]
