# Copyright (c) 2026 Apple Inc.
# SPDX-License-Identifier: Apache-2.0

"""DeepSeek V4 switch layers with an experimental MXFP4 block-list MoE GEMM."""

from __future__ import annotations

import math
import os
from functools import lru_cache

import mlx.core as mx
import mlx.nn as nn

from mlx_lm.models.activations import swiglu
from omlx.custom_kernels.glm_moe_dsa import fast as glm_fast
from omlx.custom_kernels.nax import is_nax_available
from omlx.patches.m5_gather_qmm import fused_gate_up_activation
from omlx.patches.moe_routes import sort_routes

_DEEPSEEK_MXFP4_SMALL_BLOCK_BM = 16
_DEEPSEEK_MXFP4_SMALL_BLOCK_VARIANT = 1
_DEEPSEEK_MXFP4_LARGE_BLOCK_BM = 32
_DEEPSEEK_MXFP4_LARGE_BLOCK_VARIANT = 2
_DEEPSEEK_AFFINE_LARGE_BLOCK_MIN_ROUTES = 8192
# Affine 2/3-bit g64 crossovers measured on M1 Ultra. Other formats keep
# their existing 64-route sorting threshold.
_SORT_MIN_ROUTES = int(os.environ.get("OMLX_DEEPSEEK_SORT_MIN_ROUTES", "32"))
_AFFINE_NATIVE_MIN_ROUTES = int(
    os.environ.get("OMLX_DEEPSEEK_AFFINE_BLOCK_MIN_ROUTES", "1024")
)
# Tuned on M3 Ultra. Set this to 8192 to restore the previous crossover on
# other pre-NAX chips; M5 prefill uses the NAX fallback below.
_DEEPSEEK_MXFP4_LARGE_BLOCK_MIN_ROUTES = int(
    os.environ.get("OMLX_DEEPSEEK_MXFP4_LARGE_BLOCK_MIN_ROUTES", "16384")
)

# On NAX GPUs (M5 family) mx.gather_qmm dispatches to the tensor-unit
# gather_qmm_rhs_nax kernels, which beat the pre-NAX block-list kernels for
# prefill-sized route counts (same regression shape as the Qwen qmm patch:
# 4k pp 828 -> 400 tok/s on M5 Max). Decode-sized calls stay on the block
# kernels pending M5 measurements. OMLX_DEEPSEEK_MOE_NAX=0 keeps the block
# kernels everywhere, =1 routes every call to stock on NAX GPUs.
_NAX_STOCK_MODE = os.environ.get("OMLX_DEEPSEEK_MOE_NAX", "").strip().lower()
_NAX_STOCK_MIN_ROUTES = int(
    os.environ.get("OMLX_DEEPSEEK_MOE_NAX_MIN_ROUTES", "1024")
)


def _nax_prefers_stock(num_routes: int) -> bool:
    if _NAX_STOCK_MODE in ("0", "false", "off"):
        return False
    if not is_nax_available():
        return False
    if _NAX_STOCK_MODE in ("1", "true", "on"):
        return True
    return num_routes >= _NAX_STOCK_MIN_ROUTES


def _sort_threshold(*projections) -> int:
    if all(
        isinstance(p, QuantizedSwitchLinear)
        and p.mode == "affine"
        and p.bits in (2, 3)
        and p.group_size == 64
        for p in projections
    ):
        return _SORT_MIN_ROUTES
    return 64


def has_native_block_kernels(projection) -> bool:
    """Whether ``projection``'s format has native block/pair gather kernels.

    MXFP4 (4-bit, group 32) and affine 2/3-bit group-64 experts can run gate
    and up through the native pair kernels; every other format runs them as
    stock ``gather_qmm`` calls.
    """
    if not isinstance(projection, QuantizedSwitchLinear):
        return False
    mode, bits, group_size = projection.mode, projection.bits, projection.group_size
    return (mode == "mxfp4" and bits == 4 and group_size == 32) or (
        mode == "affine" and bits in (2, 3) and group_size == 64
    )


def _gather_sort(x, indices):
    x, row_map, indices, inv_order = sort_routes(x, indices)
    return x[row_map], indices, inv_order


def _scatter_unsort(x, inv_order, shape=None):
    x = x[inv_order]
    if shape is not None:
        x = mx.unflatten(x, 0, shape)
    return x


@lru_cache(maxsize=None)
def _mxfp4_block_builder(num_experts: int, bm: int):
    source = r"""
        const uint expert = thread_index_in_threadgroup;

        threadgroup atomic_int local_count;
        if (expert == 0) {
            atomic_store_explicit(&local_count, 0, memory_order_relaxed);
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);

        if (expert >= NUM_EXPERTS) {
            return;
        }

        int lo = 0;
        int hi = M;
        while (lo < hi) {
            int mid = (lo + hi) >> 1;
            if (indices[mid] < int(expert)) {
                lo = mid + 1;
            } else {
                hi = mid;
            }
        }
        const int start = lo;

        hi = M;
        while (lo < hi) {
            int mid = (lo + hi) >> 1;
            if (indices[mid] <= int(expert)) {
                lo = mid + 1;
            } else {
                hi = mid;
            }
        }
        const int end = lo;

        for (int row = start; row < end; row += BM) {
            const int rows = min(BM, end - row);
            const int slot = atomic_fetch_add_explicit(
                &local_count, 1, memory_order_relaxed);
            if (slot < MAX_BLOCKS) {
                block_meta[slot * 3 + 0] = row;
                block_meta[slot * 3 + 1] = int(expert);
                block_meta[slot * 3 + 2] = rows;
            }
        }

        threadgroup_barrier(mem_flags::mem_threadgroup);
        if (expert == 0) {
            block_count[0] = atomic_load_explicit(
                &local_count, memory_order_relaxed);
        }
    """

    return mx.fast.metal_kernel(
        name=f"deepseek_v4_mxfp4_block_builder_e{num_experts}_bm{bm}",
        input_names=["indices"],
        output_names=["block_meta", "block_count"],
        source=source,
        ensure_row_contiguous=True,
    )


def _build_mxfp4_blocks(indices: mx.array, num_experts: int, bm: int):
    indices = indices.astype(mx.int32)
    max_blocks = (indices.size + bm - 1) // bm + num_experts
    builder = _mxfp4_block_builder(num_experts, bm)
    return builder(
        inputs=[indices],
        template=[
            ("NUM_EXPERTS", num_experts),
            ("BM", bm),
            ("M", indices.size),
            ("MAX_BLOCKS", max_blocks),
        ],
        grid=(num_experts, 1, 1),
        threadgroup=(num_experts, 1, 1),
        output_shapes=[(max_blocks, 3), (1,)],
        output_dtypes=[mx.int32, mx.int32],
    )


def _block_config(num_routes: int, native_kind: str) -> tuple[int, int]:
    if native_kind == "mxfp4":
        large_block_min_routes = _DEEPSEEK_MXFP4_LARGE_BLOCK_MIN_ROUTES
    elif native_kind == "affine":
        large_block_min_routes = _DEEPSEEK_AFFINE_LARGE_BLOCK_MIN_ROUTES
    else:
        raise ValueError(f"Unsupported native block kind: {native_kind}")

    if num_routes >= large_block_min_routes:
        return (
            _DEEPSEEK_MXFP4_LARGE_BLOCK_BM,
            _DEEPSEEK_MXFP4_LARGE_BLOCK_VARIANT,
        )
    return (
        _DEEPSEEK_MXFP4_SMALL_BLOCK_BM,
        _DEEPSEEK_MXFP4_SMALL_BLOCK_VARIANT,
    )


def _unpack_mxfp4_block_plan(block_plan):
    if len(block_plan) == 3:
        return block_plan
    block_meta, block_count = block_plan
    return block_meta, block_count, _DEEPSEEK_MXFP4_SMALL_BLOCK_VARIANT


class QuantizedSwitchLinear(nn.Module):
    def __init__(
        self,
        input_dims: int,
        output_dims: int,
        num_experts: int,
        bias: bool = True,
        group_size: int = 64,
        bits: int = 4,
        mode: str = "affine",
    ):
        super().__init__()

        scale = math.sqrt(1 / input_dims)
        self.weight, self.scales, *biases = mx.quantize(
            mx.random.uniform(
                low=-scale,
                high=scale,
                shape=(num_experts, output_dims, input_dims),
            ),
            group_size=group_size,
            bits=bits,
            mode=mode,
        )
        self.biases = biases[0] if biases else None

        if bias:
            self.bias = mx.zeros((num_experts, output_dims))

        self.group_size = group_size
        self.bits = bits
        self.mode = mode

        self.freeze()

    @property
    def input_dims(self):
        return self.scales.shape[2] * self.group_size

    @property
    def output_dims(self):
        return self.weight.shape[1]

    @property
    def num_experts(self):
        return self.weight.shape[0]

    def _can_use_mxfp4_blocks(self, x, sorted_indices: bool) -> bool:
        return (
            sorted_indices
            and x.ndim == 3
            and x.shape[-2] == 1
            and self.group_size == 32
            and self.bits == 4
            and self.mode == "mxfp4"
            and self.get("biases") is None
            and "bias" not in self
            and self["weight"].dtype == mx.uint32
            and self["scales"].dtype == mx.uint8
            and glm_fast.has_symbol("deepseek_mxfp4_gather_qmm_blocks")
        )

    def _can_use_affine_blocks(self, x, sorted_indices: bool, dtype=None) -> bool:
        dtype = dtype or x.dtype
        biases = self.get("biases")
        return (
            sorted_indices
            and x.ndim == 3
            and x.shape[-2] == 1
            and int(x.shape[0]) >= _AFFINE_NATIVE_MIN_ROUTES
            and dtype in (mx.float16, mx.bfloat16)
            and self.group_size == 64
            and self.bits in (2, 3)
            and self.mode == "affine"
            and biases is not None
            and "bias" not in self
            and self["weight"].dtype == mx.uint32
            and self["scales"].dtype == dtype
            and biases.dtype == dtype
            and glm_fast.has_symbol("deepseek_affine_gather_qmm_blocks")
        )

    def _has_affine_metadata_dtype(self, dtype) -> bool:
        """Return whether affine quantization metadata uses ``dtype``."""
        biases = self.get("biases")
        return (
            self.mode == "affine"
            and biases is not None
            and "bias" not in self
            and self["weight"].dtype == mx.uint32
            and self["scales"].dtype == dtype
            and biases.dtype == dtype
        )

    def _native_block_kind(self, x, sorted_indices: bool, dtype=None) -> str | None:
        if x.ndim == 3 and _nax_prefers_stock(int(x.shape[0])):
            return None
        if self._can_use_mxfp4_blocks(x, sorted_indices):
            return "mxfp4"
        if self._can_use_affine_blocks(x, sorted_indices, dtype=dtype):
            return "affine"
        return None

    def __call__(self, x, indices, sorted_indices=False, block_plan=None):
        native_kind = self._native_block_kind(x, sorted_indices)
        if native_kind is not None:
            if block_plan is None:
                block_bm, block_variant = _block_config(indices.size, native_kind)
                block_meta, block_count = _build_mxfp4_blocks(
                    indices,
                    self.num_experts,
                    block_bm,
                )
            else:
                block_meta, block_count, block_variant = _unpack_mxfp4_block_plan(
                    block_plan
                )
            if native_kind == "mxfp4":
                x = glm_fast.deepseek_mxfp4_gather_qmm_blocks(
                    x,
                    self["weight"],
                    self["scales"],
                    block_meta,
                    block_count,
                    block_variant,
                )
            else:
                x = glm_fast.deepseek_affine_gather_qmm_blocks(
                    x,
                    self["weight"],
                    self["scales"],
                    self["biases"],
                    block_meta,
                    block_count,
                    self.group_size,
                    self.bits,
                    block_variant,
                )
        else:
            x = mx.gather_qmm(
                x,
                self["weight"],
                self["scales"],
                self.get("biases"),
                rhs_indices=indices,
                transpose=True,
                group_size=self.group_size,
                bits=self.bits,
                mode=self.mode,
                sorted_indices=sorted_indices,
            )
        if "bias" in self:
            x = x + mx.expand_dims(self["bias"][indices], -2)
        return x


class SwitchLinear(nn.Module):
    def __init__(
        self, input_dims: int, output_dims: int, num_experts: int, bias: bool = True
    ):
        super().__init__()
        scale = math.sqrt(1 / input_dims)
        self.weight = mx.random.uniform(
            low=-scale,
            high=scale,
            shape=(num_experts, output_dims, input_dims),
        )

        if bias:
            self.bias = mx.zeros((num_experts, output_dims))

    @property
    def input_dims(self):
        return self.weight.shape[2]

    @property
    def output_dims(self):
        return self.weight.shape[1]

    @property
    def num_experts(self):
        return self.weight.shape[0]

    def __call__(self, x, indices, sorted_indices=False, block_plan=None):
        del block_plan
        x = mx.gather_mm(
            x,
            self["weight"].swapaxes(-1, -2),
            rhs_indices=indices,
            sorted_indices=sorted_indices,
        )
        if "bias" in self:
            x = x + mx.expand_dims(self["bias"][indices], -2)
        return x

    def to_quantized(self, group_size: int = 64, bits: int = 4, mode: str = "affine"):
        num_experts, output_dims, input_dims = self.weight.shape
        ql = QuantizedSwitchLinear(
            input_dims,
            output_dims,
            num_experts,
            False,
            group_size,
            bits,
            mode=mode,
        )
        ql.weight, ql.scales, *biases = mx.quantize(
            self.weight, group_size, bits, mode=mode
        )
        ql.biases = biases[0] if biases else None

        if "bias" in self:
            ql.bias = self.bias
        return ql


class SwiGLU(nn.Module):
    def __init__(self):
        super().__init__()

    def __call__(self, x, gate):
        return swiglu(gate, x)


class SwitchGLU(nn.Module):
    def __init__(
        self,
        input_dims: int,
        hidden_dims: int,
        num_experts: int,
        activation=SwiGLU(),
        bias: bool = False,
    ):
        super().__init__()

        self.gate_proj = SwitchLinear(input_dims, hidden_dims, num_experts, bias=bias)
        self.up_proj = SwitchLinear(input_dims, hidden_dims, num_experts, bias=bias)
        self.down_proj = SwitchLinear(hidden_dims, input_dims, num_experts, bias=bias)
        self.activation = activation

    def projections(self) -> tuple:
        """Expert projections in call order: gate/up (or fused), then down."""
        if "gate_up_proj" in self:
            return (self.gate_up_proj, self.down_proj)
        return (self.up_proj, self.gate_proj, self.down_proj)

    def __call__(self, x, indices, scores=None, weighted_sum=False) -> mx.array:
        x = mx.expand_dims(x, (-2, -3))
        original_dtype = x.dtype
        projections = self.projections()
        fused_gate_up = len(projections) == 2

        do_sort = indices.size >= _sort_threshold(*projections)
        idx = indices
        inv_order = None
        token_rows = None
        if do_sort:
            # The replicated rows x_tok[row_map] stay lazy: never computed
            # when the fused gate/up kernel reads the token rows in place.
            x_tok, row_map, idx, inv_order = sort_routes(x, indices)
            x = x_tok[row_map]
            token_rows = (x_tok, row_map)
        if self.training:
            idx = mx.stop_gradient(idx)

        block_plan = None
        native_kinds = None
        use_f16_moe = original_dtype == mx.bfloat16 and all(
            isinstance(p, QuantizedSwitchLinear)
            and p._has_affine_metadata_dtype(mx.float16)
            for p in projections
        )
        if do_sort and all(isinstance(p, QuantizedSwitchLinear) for p in projections):
            native_kinds = tuple(p._native_block_kind(x, do_sort) for p in projections)
            if x.dtype == mx.bfloat16:
                f16_native_kinds = tuple(
                    p._native_block_kind(x, do_sort, dtype=mx.float16)
                    for p in projections
                )
                if all(kind == "mxfp4" for kind in f16_native_kinds) or all(
                    kind == "affine" for kind in f16_native_kinds
                ):
                    native_kinds = f16_native_kinds
                    use_f16_moe = True
            if all(kind is not None for kind in native_kinds):
                block_kind = (
                    "mxfp4"
                    if all(kind == "mxfp4" for kind in native_kinds)
                    else "affine"
                )
                block_bm, block_variant = _block_config(idx.size, block_kind)
                block_meta, block_count = _build_mxfp4_blocks(
                    idx,
                    self.down_proj.num_experts,
                    block_bm,
                )
                block_plan = (block_meta, block_count, block_variant)

        if use_f16_moe:
            x = x.astype(mx.float16)
            if token_rows is not None:
                token_rows = (token_rows[0].astype(mx.float16), token_rows[1])

        use_pair_proj = (
            not fused_gate_up
            and block_plan is not None
            and native_kinds is not None
            and native_kinds[0] == "mxfp4"
            and native_kinds[1] == "mxfp4"
            and glm_fast.has_symbol("deepseek_mxfp4_gather_qmm_pair_blocks")
            and self.up_proj.output_dims == self.gate_proj.output_dims
            and self.up_proj.num_experts == self.gate_proj.num_experts
        )
        use_affine_pair_proj = (
            not fused_gate_up
            and block_plan is not None
            and native_kinds is not None
            and native_kinds[0] == "affine"
            and native_kinds[1] == "affine"
            and self.up_proj.group_size == self.gate_proj.group_size
            and self.up_proj.bits == self.gate_proj.bits
            and self.up_proj.output_dims == self.gate_proj.output_dims
            and self.up_proj.num_experts == self.gate_proj.num_experts
            and glm_fast.has_symbol("deepseek_affine_gather_qmm_pair_concat_blocks")
        )
        x_act = None
        if fused_gate_up:
            if (
                do_sort
                and block_plan is None
                and not self.training
                and isinstance(self.gate_up_proj, QuantizedSwitchLinear)
            ):
                # Sorted prefill on M5 (stock gather_qmm route): the
                # activation in the [gate; up] matmul's epilogue
                # (bit-identical; None keeps the path below).
                x_act = fused_gate_up_activation(
                    self.gate_up_proj, x, idx, self.activation, token_rows=token_rows
                )
            if x_act is None:
                # One gather_qmm over the [gate; up] expert rows; each output
                # column is the same K-reduction as in the separate calls.
                x_gate_up = self.gate_up_proj(
                    x, idx, sorted_indices=do_sort, block_plan=block_plan
                )
                x_gate, x_up = mx.split(x_gate_up, 2, axis=-1)
        elif use_pair_proj:
            block_meta, block_count, block_variant = _unpack_mxfp4_block_plan(
                block_plan
            )
            if glm_fast.has_symbol("deepseek_mxfp4_gather_qmm_pair_concat_blocks"):
                x_pair = glm_fast.deepseek_mxfp4_gather_qmm_pair_concat_blocks(
                    x,
                    self.up_proj["weight"],
                    self.up_proj["scales"],
                    self.gate_proj["weight"],
                    self.gate_proj["scales"],
                    block_meta,
                    block_count,
                    block_variant,
                )
                hidden_dims = self.up_proj.output_dims
                x_up = x_pair[..., :hidden_dims]
                x_gate = x_pair[..., hidden_dims:]
            else:
                x_pair = glm_fast.deepseek_mxfp4_gather_qmm_pair_blocks(
                    x,
                    self.up_proj["weight"],
                    self.up_proj["scales"],
                    self.gate_proj["weight"],
                    self.gate_proj["scales"],
                    block_meta,
                    block_count,
                    block_variant,
                )
                x_up = x_pair[0]
                x_gate = x_pair[1]
        elif use_affine_pair_proj:
            block_meta, block_count, block_variant = _unpack_mxfp4_block_plan(
                block_plan
            )
            x_pair = glm_fast.deepseek_affine_gather_qmm_pair_concat_blocks(
                x,
                self.up_proj["weight"],
                self.up_proj["scales"],
                self.up_proj["biases"],
                self.gate_proj["weight"],
                self.gate_proj["scales"],
                self.gate_proj["biases"],
                block_meta,
                block_count,
                self.up_proj.group_size,
                self.up_proj.bits,
                block_variant,
            )
            hidden_dims = self.up_proj.output_dims
            x_up = x_pair[..., :hidden_dims]
            x_gate = x_pair[..., hidden_dims:]
        else:
            x_up = self.up_proj(x, idx, sorted_indices=do_sort, block_plan=block_plan)
            x_gate = self.gate_proj(
                x, idx, sorted_indices=do_sort, block_plan=block_plan
            )
        x = self.activation(x_up, x_gate) if x_act is None else x_act
        if (
            block_plan is not None
            and native_kinds is not None
            and native_kinds[-1] == "affine"
            and isinstance(self.down_proj, QuantizedSwitchLinear)
            and x.dtype != self.down_proj["scales"].dtype
            and self.down_proj["scales"].dtype in (mx.float16, mx.bfloat16)
        ):
            x = x.astype(self.down_proj["scales"].dtype)
        x = self.down_proj(
            x,
            idx,
            sorted_indices=do_sort,
            block_plan=block_plan,
        )

        if (
            weighted_sum
            and scores is not None
            and do_sort
            and scores.shape[-1] in (6, 8)
            and scores.dtype == mx.float32
            and x.dtype in (mx.float16, mx.bfloat16)
            and glm_fast.has_symbol("glm_moe_weighted_sum")
        ):
            y = glm_fast.glm_moe_weighted_sum(x, inv_order, scores)
            return y.astype(original_dtype) if use_f16_moe else y

        if do_sort:
            x = _scatter_unsort(x, inv_order, indices.shape)

        x = x.squeeze(-2)
        if use_f16_moe:
            x = x.astype(original_dtype)
        return x


class SwitchMLP(nn.Module):
    def __init__(
        self,
        input_dims: int,
        hidden_dims: int,
        num_experts: int,
        activation=nn.GELU(approx="precise"),
        bias: bool = False,
    ):
        super().__init__()

        self.fc1 = SwitchLinear(input_dims, hidden_dims, num_experts, bias=bias)
        self.fc2 = SwitchLinear(hidden_dims, input_dims, num_experts, bias=bias)
        self.activation = activation

    def __call__(self, x, indices) -> mx.array:
        x = mx.expand_dims(x, (-2, -3))

        do_sort = indices.size >= _sort_threshold(self.fc1, self.fc2)
        idx = indices
        inv_order = None
        if do_sort:
            x, idx, inv_order = _gather_sort(x, indices)
        if self.training:
            idx = mx.stop_gradient(idx)
        x = self.fc1(x, idx, sorted_indices=do_sort)
        x = self.activation(x)
        x = self.fc2(x, idx, sorted_indices=do_sort)

        if do_sort:
            x = _scatter_unsort(x, inv_order, indices.shape)

        return x.squeeze(-2)
