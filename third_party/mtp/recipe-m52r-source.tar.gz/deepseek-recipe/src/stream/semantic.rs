//! Synchronous semantic state shared by canonical parsing and read-only preview.

use std::sync::{Arc, Mutex};

use super::StreamError;
use super::decoder::{StreamDecoder, TokenizerDecoder};
use super::state_machine::{OutputActionSegment, ParsingOptions, SemanticTerminal, StateMachine};

/// Earliest terminal in candidate IDs. Count excludes its completing token.
/// Source spans are absolute decoded-source bytes, not tokenization offsets.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SemanticPreview {
    pub terminal: Option<SemanticTerminal>,
    pub completing_token_index: Option<usize>,
    pub safe_token_count: usize,
    pub mapping_exact: bool,
    pub candidate_ids_processed: usize,
    pub max_pending_ids: usize,
}

/// Contains only incremental parser/decoder state, never output history or a
/// protocol generator. Clone copies pending IDs and KMP/stage state and shares
/// the immutable decoding implementation.
#[derive(Clone)]
pub struct SemanticSession {
    machine: StateMachine,
    decoder: Option<StreamDecoder>,
    ended: bool,
}

impl SemanticSession {
    pub fn new(options: ParsingOptions) -> Self {
        Self {
            machine: StateMachine::new(options),
            decoder: None,
            ended: false,
        }
    }

    pub fn with_tokenizer(mut self, decoder: impl TokenizerDecoder + 'static) -> Self {
        self.decoder = Some(StreamDecoder::new(Box::new(decoder)));
        self
    }

    #[cfg(test)]
    pub(crate) fn test_fingerprint(&self) -> String {
        format!(
            "{:?}|{:?}|{}",
            self.machine,
            self.decoder.as_ref().map(|d| d.test_state()),
            self.ended
        )
    }

    /// Diagnostic identity only, not a persisted state or parser restore API.
    /// The fingerprint includes every parser field and decoder pending count.
    pub fn diagnostic_snapshot(&self) -> (String, Vec<u32>, usize, usize) {
        use std::hash::{Hash, Hasher};
        let count = self.decoder.as_ref().map_or(0, |d| d.pending_count());
        let mut hash = std::collections::hash_map::DefaultHasher::new();
        format!("{:?}|{:?}|{}|{}", self.machine, self.pending_ids(), count, self.ended).hash(&mut hash);
        (format!("{:016x}", hash.finish()), self.pending_ids().to_vec(), count, self.source_bytes())
    }

    pub fn terminal(&self) -> Option<&SemanticTerminal> {
        self.machine.terminal()
    }
    pub fn source_bytes(&self) -> usize {
        self.machine.source_bytes()
    }
    pub fn pending_ids(&self) -> &[u32] {
        self.decoder
            .as_ref()
            .map(|d| d.pending_ids())
            .unwrap_or(&[])
    }

    /// Decode and feed as one atomic synchronous step. The returned source and
    /// actions are consumed by the existing canonical protocol stashing code.
    pub fn token(
        &mut self,
        id: u32,
    ) -> Result<Option<(String, usize, Vec<OutputActionSegment>)>, StreamError> {
        if self.ended {
            return Err(StreamError::Decode {
                detail: "semantic input ended".into(),
            });
        }
        let decoder = self.decoder.as_mut().ok_or(StreamError::MissingTokenizer)?;
        let Some((content, tokens)) = decoder.decode(id)? else {
            return Ok(None);
        };
        let actions = self.machine.feed(&content);
        Ok(Some((content, tokens, actions)))
    }

    pub fn text(&mut self, content: &str) -> Result<Vec<OutputActionSegment>, StreamError> {
        if self.ended {
            return Err(StreamError::Decode {
                detail: "semantic input ended".into(),
            });
        }
        Ok(self.machine.feed(content))
    }

    pub fn finish(&mut self) -> Vec<OutputActionSegment> {
        if self.ended {
            return Vec::new();
        }
        self.ended = true;
        // Original finish consumes the parser. Leave its last terminal/span
        // accessible after normal stream completion, without a history replay.
        self.machine.clone().finish()
    }

    pub fn preview_tokens(&self, ids: &[u32]) -> Result<SemanticPreview, StreamError> {
        let decoder = self.decoder.as_ref().ok_or(StreamError::MissingTokenizer)?;
        let mut result = SemanticPreview {
            terminal: self.terminal().cloned(),
            completing_token_index: None,
            safe_token_count: 0,
            mapping_exact: false,
            candidate_ids_processed: 0,
            max_pending_ids: decoder.pending_ids().len(),
        };
        // No meaningful candidate-relative map after canonical terminal/EOF.
        if self.ended || self.terminal().is_some() || !decoder.supports_semantic_preview() {
            return Ok(result);
        }
        let mut fork = self.clone();
        result.mapping_exact = true;
        for (index, id) in ids.iter().enumerate() {
            result.max_pending_ids = result.max_pending_ids.max(fork.pending_ids().len() + 1);
            fork.token(*id)?;
            result.candidate_ids_processed += 1;
            if let Some(terminal) = fork.terminal() {
                result.terminal = Some(terminal.clone());
                result.completing_token_index = Some(index);
                result.safe_token_count = index;
                return Ok(result);
            }
        }
        result.safe_token_count = ids.len();
        Ok(result)
    }
}

/// A processor retains this handle before consuming itself into its async
/// stream. Python serializes preview with push/drain at the next-input boundary.
/// Rust callers must likewise invoke preview only at their canonical input
/// boundary, not while another task is feeding input.
#[derive(Clone)]
pub struct SemanticSessionHandle(pub(crate) Arc<Mutex<SemanticSession>>);

impl SemanticSessionHandle {
    pub(crate) fn new(options: ParsingOptions) -> Self {
        Self(Arc::new(Mutex::new(SemanticSession::new(options))))
    }

    pub(crate) fn set_tokenizer(&self, decoder: impl TokenizerDecoder + 'static) {
        self.0.lock().expect("semantic lock poisoned").decoder =
            Some(StreamDecoder::new(Box::new(decoder)));
    }

    pub(crate) fn token(
        &self,
        id: u32,
    ) -> Result<Option<(String, usize, Vec<OutputActionSegment>)>, StreamError> {
        self.0
            .lock()
            .map_err(|_| StreamError::Decode {
                detail: "semantic lock poisoned".into(),
            })?
            .token(id)
    }

    pub(crate) fn text(&self, content: &str) -> Result<Vec<OutputActionSegment>, StreamError> {
        self.0
            .lock()
            .map_err(|_| StreamError::Decode {
                detail: "semantic lock poisoned".into(),
            })?
            .text(content)
    }

    pub(crate) fn finish(&self) -> Result<Vec<OutputActionSegment>, StreamError> {
        Ok(self
            .0
            .lock()
            .map_err(|_| StreamError::Decode {
                detail: "semantic lock poisoned".into(),
            })?
            .finish())
    }

    pub fn preview_tokens(&self, ids: &[u32]) -> Result<SemanticPreview, StreamError> {
        self.0
            .lock()
            .map_err(|_| StreamError::Decode {
                detail: "semantic lock poisoned".into(),
            })?
            .preview_tokens(ids)
    }

    pub fn fork(&self) -> Result<SemanticSession, StreamError> {
        Ok(self.0.lock().map_err(|_| StreamError::Decode {
            detail: "semantic lock poisoned".into(),
        })?.clone())
    }

    pub fn diagnostic_snapshot(&self) -> Result<(String, Vec<u32>, usize, usize), StreamError> {
        Ok(self.0.lock().map_err(|_| StreamError::Decode {
            detail: "semantic lock poisoned".into(),
        })?.diagnostic_snapshot())
    }

    pub fn terminal(&self) -> Result<Option<SemanticTerminal>, StreamError> {
        Ok(self
            .0
            .lock()
            .map_err(|_| StreamError::Decode {
                detail: "semantic lock poisoned".into(),
            })?
            .terminal()
            .cloned())
    }
}
