# Candidate incremental semantic preview API

This local candidate change is based on 8cadfede7063c896b944e7bae05daa3549ae97ea.
It adds observations without changing protocol output/finish behavior.

`StreamProcessor` now owns a `SemanticSessionHandle` pointing to an explicit
synchronous `SemanticSession`. Canonical token decode + parser feed is one
synchronous step. No mutex guard spans a protocol generator await. The Python
binding retains the handle before consuming the processor into its async stream;
its existing mutex serializes push/drain and preview at the next-input boundary.
Rust callers must likewise serialize input and preview at an input boundary.

`SemanticSession` forks only StateMachine and decoder mutable state: parser stage,
KMP prefixes/tables, stashed byte count, reasoning/newline/JSON state, pending
IDs/count, absolute decoded byte offset and first terminal observation. No
protocol generator, stashed protocol chunks, async input channel or generated
history is cloned. Protocol stashing still consumes the exact original actions.

The decode implementation is shared using Arc<Mutex<Box<dyn TokenizerDecoder>>>;
the mutex preserves the existing Send-only trait bound. The tokenizer itself is
not copied. Decode still calls decode_ids(pending_ids, false), holds empty text or
text ending in U+FFFD, and resets pending state only on a successful text flush.
Custom decoders opt in to preview only if immutable and deterministic; the default
supports_semantic_preview is false. The standard Tokenizer and its Arc delegate
opt in. Unsupported custom decoding returns inexact mapping and zero safe count,
without calling that decoder. Missing tokenizer/decode errors return an error.

The StateMachine records the actual matched transition into Finished. The
additional semantic observation distinguishes STOP_SEQUENCE from
DSML_TOOL_CALL_BLOCK_END, and records an absolute half-open decoded-byte span.
DSML opening or invocation closure is not terminal; JSON fence closure is not
terminal. `finished` retains its original protocol stream meaning. DSML terminal
metadata does not close the stream or invent a backend finish reason.

Python:

```python
result = processor.preview_tokens(candidate_ids)
result.terminal_kind             # None, STOP_SEQUENCE, DSML_TOOL_CALL_BLOCK_END
result.completing_token_index    # None or zero-based candidate index
result.safe_token_count          # candidate IDs before completing token
result.source_start              # None or absolute decoded-source byte position
result.source_end                # None or exclusive end
result.mapping_exact             # false => caller must fail closed
result.candidate_ids_processed
result.max_pending_ids
processor.semantic_terminal      # actual canonical observation, not preview
```

A flush caused by candidate j can include IDs pending before preview. Its first
terminal transition maps exactly to j under the canonical decoder contract.
Earlier candidate IDs that produced no text remain in the safe prefix. Span start
can precede this call. The result never re-tokenizes decoded text or rounds byte
positions forward. No terminal yields safe count equal to candidate count.
Already-terminal/ended session yields mapping_exact=false and safe count zero;
closed/finished Python streams reject preview. Canonical semantic metadata is
readable after normal protocol completion, but not after close/error.

The fork stops after the first terminal-producing flush. The authoritative feed
may consume the entire flush including an invalid tail, exactly as canonical feed
does; the returned span remains the first terminal byte span and the completing
candidate must remain outside any speculative target-committed drained prefix.

State-copy cost is independent of generated history length, but proportional to
configured matcher patterns and pending IDs. The existing decoder contract can
retain an arbitrarily long group if decoding never produces a usable flush; this
change does not promise a fixed maximum pending size. Callers may impose separate
eligibility/resource bounds, not change detokenization.

Tests: `cargo test -p deepseek-recipe`, plus
`deepseek-recipe-python/tests/test_semantic_preview.py` after a real native build.
The consuming ds41f M31 source driver compares raw outputs and chat events against
the pristine pinned source. Python/native and live MTP qualification are separate
prerequisites; this extension alone does not authorize speculative serving.
