//! Decode token ids into text for the stream processor.

use std::sync::{Arc, Mutex};

use tokenizers::Tokenizer;

use super::StreamError;

/// Replacement character emitted while a multi-token character is incomplete.
const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

/// Decode token ids into text.
///
/// Implemented for [`Tokenizer`]; other backends can implement it to feed a
/// stream processor.
pub trait TokenizerDecoder: Send {
    /// Decode `ids` into text, skipping special tokens when requested.
    fn decode_ids(&self, ids: &[u32], skip_special_tokens: bool) -> Result<String, String>;

    /// Opt in only for immutable, deterministic decoding. Preview reuses this
    /// decoder; stateful custom decoders must not opt in.
    fn supports_semantic_preview(&self) -> bool {
        false
    }
}

impl TokenizerDecoder for Tokenizer {
    fn supports_semantic_preview(&self) -> bool {
        true
    }

    fn decode_ids(&self, ids: &[u32], skip_special_tokens: bool) -> Result<String, String> {
        self.decode(ids, skip_special_tokens)
            .map_err(|error| error.to_string())
    }
}

impl<T> TokenizerDecoder for Arc<T>
where
    T: TokenizerDecoder + Sync,
{
    fn decode_ids(&self, ids: &[u32], skip_special_tokens: bool) -> Result<String, String> {
        (**self).decode_ids(ids, skip_special_tokens)
    }

    fn supports_semantic_preview(&self) -> bool {
        (**self).supports_semantic_preview()
    }
}

/// Buffer token ids until they decode into text.
#[derive(Clone)]
pub struct StreamDecoder {
    // Shared immutable decode implementation; never copy tokenizer/model data.
    decoder: Arc<Mutex<Box<dyn TokenizerDecoder>>>,
    ids: Vec<u32>,
    pending: usize,
}

impl StreamDecoder {
    pub fn new(decoder: Box<dyn TokenizerDecoder>) -> Self {
        Self {
            decoder: Arc::new(Mutex::new(decoder)),
            ids: Vec::new(),
            pending: 0,
        }
    }

    pub fn pending_ids(&self) -> &[u32] {
        &self.ids
    }

    pub fn pending_count(&self) -> usize {
        self.pending
    }

    #[cfg(test)]
    pub(crate) fn test_state(&self) -> (&[u32], usize) {
        (&self.ids, self.pending)
    }

    pub fn supports_semantic_preview(&self) -> bool {
        self.decoder
            .lock()
            .map(|d| d.supports_semantic_preview())
            .unwrap_or(false)
    }

    /// Return the text contributed by the buffered token ids and the number of
    /// ids it accounts for, or `None` while no text is available yet.
    ///
    /// Special tokens drive the parser's state machine, so they stay in the
    /// decoded text. A decoder failure is returned as a stream error.
    pub fn decode(&mut self, token_id: u32) -> Result<Option<(String, usize)>, StreamError> {
        self.pending += 1;
        self.ids.push(token_id);
        let content = self
            .decoder
            .lock()
            .map_err(|_| StreamError::Decode {
                detail: "decoder lock poisoned".into(),
            })?
            .decode_ids(&self.ids, false)
            .map_err(|detail| StreamError::Decode { detail })?;
        if content.is_empty() || content.ends_with(REPLACEMENT_CHARACTER) {
            return Ok(None);
        }
        self.ids.clear();
        Ok(Some((content, std::mem::take(&mut self.pending))))
    }
}
