use super::semantic::SemanticSession;
use super::state_machine::{ParsingOptions, ReasoningStage, SemanticTerminalKind};
use super::{
    ChunkGenerator, InferenceChunk, InferenceFinishReason, OutputChunk, StreamProcessor,
    TokenizerDecoder,
};
use std::sync::Arc;
use tokenizers::Tokenizer;
use tokio_stream::StreamExt;

fn tokenizer() -> Arc<Tokenizer> {
    let path = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .unwrap()
        .join("static/tokenizers/v41/tokenizer.json");
    Arc::new(Tokenizer::from_file(path).unwrap())
}

fn ids(t: &Tokenizer, text: &str) -> Vec<u32> {
    t.encode(text, false).unwrap().get_ids().to_vec()
}

fn options(stops: &[&str]) -> ParsingOptions {
    ParsingOptions {
        stop_sequences: stops.iter().map(|s| s.to_string()).collect(),
        ..Default::default()
    }
}

fn feed(session: &mut SemanticSession, tokens: &[u32]) {
    for id in tokens {
        session.token(*id).unwrap();
    }
}

const CALL: &str = "<｜DSML｜ calls>\n<｜DSML｜ invoke name=\"lookup\">\n<｜DSML｜ parameter name=\"city\" string=\"true\">Paris</｜DSML｜ parameter>\n</｜DSML｜ invoke>\n</｜DSML｜ calls>";

#[test]
fn every_dsml_token_split_is_an_exact_nonmutating_preview() {
    let t = tokenizer();
    let tokens = ids(&t, CALL);
    for split in 0..tokens.len() {
        let mut canonical = SemanticSession::new(options(&[])).with_tokenizer(t.clone());
        feed(&mut canonical, &tokens[..split]);
        assert!(canonical.terminal().is_none());
        let before = canonical.test_fingerprint();
        let result = canonical.preview_tokens(&tokens[split..]).unwrap();
        assert_eq!(before, canonical.test_fingerprint());
        assert_eq!(result, canonical.preview_tokens(&tokens[split..]).unwrap());
        assert!(result.mapping_exact);
        assert_eq!(
            result.completing_token_index,
            Some(tokens.len() - split - 1)
        );
        assert_eq!(result.safe_token_count, tokens.len() - split - 1);
        let terminal = result.terminal.unwrap();
        assert_eq!(terminal.kind, SemanticTerminalKind::DsmlToolCallBlockEnd);
        assert_eq!(
            &CALL.as_bytes()[terminal.source_start..terminal.source_end],
            "</｜DSML｜ calls>".as_bytes()
        );
        feed(&mut canonical, &tokens[split..]);
        assert_eq!(canonical.terminal(), Some(&terminal));
    }
}

#[test]
fn pending_canonical_utf8_ids_and_candidate_group() {
    let t = tokenizer();
    let tokens = ids(&t, "🙂");
    assert!(tokens.len() > 1);
    let mut canonical = SemanticSession::new(options(&["🙂"])).with_tokenizer(t);
    feed(&mut canonical, &tokens[..1]);
    assert_eq!(canonical.source_bytes(), 0);
    assert_eq!(canonical.pending_ids(), &tokens[..1]);
    let before = canonical.test_fingerprint();
    let p = canonical.preview_tokens(&tokens[1..]).unwrap();
    assert_eq!(p.completing_token_index, Some(tokens.len() - 2));
    assert_eq!(p.safe_token_count, tokens.len() - 2);
    assert_eq!(p.max_pending_ids, tokens.len());
    assert_eq!(p.terminal.unwrap().source_end, "🙂".len());
    assert_eq!(before, canonical.test_fingerprint());
}

#[test]
fn stops_across_every_token_boundary_with_shared_prefix_and_unicode() {
    let t = tokenizer();
    let text = "café🙂HALT NOT yet HALT NOW";
    let tokens = ids(&t, text);
    for split in 0..tokens.len() {
        let mut canonical =
            SemanticSession::new(options(&["HALT NOW", "HALT NEVER"])).with_tokenizer(t.clone());
        feed(&mut canonical, &tokens[..split]);
        let p = canonical.preview_tokens(&tokens[split..]).unwrap();
        let terminal = p.terminal.unwrap();
        assert!(p.mapping_exact);
        assert_eq!(p.completing_token_index, Some(tokens.len() - split - 1));
        assert_eq!(terminal.kind, SemanticTerminalKind::StopSequence);
        assert_eq!(terminal.source_start, text.len() - "HALT NOW".len());
        assert_eq!(terminal.source_end, text.len());
    }
}

#[test]
fn simulated_rejection_and_partial_emission_never_repair_parser() {
    let t = tokenizer();
    let tokens = ids(&t, CALL);
    for emitted in [0, 1, tokens.len() / 2, tokens.len() - 1, tokens.len()] {
        let mut canonical = SemanticSession::new(options(&[])).with_tokenizer(t.clone());
        let mut reference = canonical.clone();
        let before = canonical.test_fingerprint();
        canonical.preview_tokens(&tokens).unwrap();
        assert_eq!(before, canonical.test_fingerprint());
        feed(&mut canonical, &tokens[..emitted]);
        feed(&mut reference, &tokens[..emitted]);
        assert_eq!(canonical.test_fingerprint(), reference.test_fingerprint());
    }
}

#[test]
fn opening_invocation_close_and_json_fence_are_not_terminal() {
    let t = tokenizer();
    for text in [
        "<｜DSML｜ calls>",
        &CALL[..CALL.rfind("</｜DSML｜ calls>").unwrap()],
    ] {
        let session = SemanticSession::new(options(&[])).with_tokenizer(t.clone());
        assert!(
            session
                .preview_tokens(&ids(&t, text))
                .unwrap()
                .terminal
                .is_none()
        );
    }
    let mut json_options = options(&[]);
    json_options.parse_json_output = true;
    let session = SemanticSession::new(json_options).with_tokenizer(t.clone());
    assert!(
        session
            .preview_tokens(&ids(&t, "```json\n{}\n``` tail"))
            .unwrap()
            .terminal
            .is_none()
    );
}

#[test]
fn reasoning_excludes_user_stops_until_content() {
    let t = tokenizer();
    let mut o = options(&["STOP"]);
    o.reasoning_initial_stage = Some(ReasoningStage::Reasoning);
    let mut session = SemanticSession::new(o).with_tokenizer(t.clone());
    let reasoning = ids(&t, "STOP thoughts");
    assert!(
        session
            .preview_tokens(&reasoning)
            .unwrap()
            .terminal
            .is_none()
    );
    feed(&mut session, &reasoning);
    assert!(
        session
            .preview_tokens(&ids(&t, "</think>STOP"))
            .unwrap()
            .terminal
            .is_some()
    );
}

#[test]
fn terminal_tail_earliest_span_and_ended_input_fail_closed() {
    let t = tokenizer();
    let mut session = SemanticSession::new(options(&[])).with_tokenizer(t.clone());
    let p = session
        .preview_tokens(&ids(&t, &(CALL.to_string() + "TAIL")))
        .unwrap();
    assert_eq!(p.terminal.as_ref().unwrap().source_end, CALL.len());
    feed(&mut session, &ids(&t, CALL));
    let p = session.preview_tokens(&ids(&t, "TAIL")).unwrap();
    assert!(!p.mapping_exact);
    assert_eq!(p.safe_token_count, 0);
    session.finish();
    assert!(!session.preview_tokens(&[]).unwrap().mapping_exact);
    assert!(session.token(1).is_err());
}

struct UnsupportedDecoder;
impl TokenizerDecoder for UnsupportedDecoder {
    fn decode_ids(&self, _: &[u32], _: bool) -> Result<String, String> {
        panic!("must not preview untrusted decoder")
    }
}

#[test]
fn custom_decoder_does_not_implicitly_claim_exactness() {
    let session = SemanticSession::new(options(&[])).with_tokenizer(UnsupportedDecoder);
    let p = session.preview_tokens(&[1, 2]).unwrap();
    assert!(!p.mapping_exact);
    assert_eq!(p.safe_token_count, 0);
    assert_eq!(p.candidate_ids_processed, 0);
}

struct FailingDecoder;
impl TokenizerDecoder for FailingDecoder {
    fn supports_semantic_preview(&self) -> bool {
        true
    }
    fn decode_ids(&self, _: &[u32], skip: bool) -> Result<String, String> {
        assert!(!skip);
        Err("test error".into())
    }
}

#[test]
fn decode_error_leaves_canonical_state_unchanged() {
    let session = SemanticSession::new(options(&[])).with_tokenizer(FailingDecoder);
    let before = session.test_fingerprint();
    assert!(session.preview_tokens(&[1]).is_err());
    assert_eq!(before, session.test_fingerprint());
}

struct Echo;
impl ChunkGenerator for Echo {
    type Chunk = OutputChunk;
    async fn generate(&mut self, chunk: OutputChunk) -> Vec<OutputChunk> {
        vec![chunk]
    }
}

#[tokio::test]
async fn canonical_processor_uses_retained_session_but_keeps_finish_behavior() {
    let t = tokenizer();
    let processor = StreamProcessor::new(Echo, options(&[])).with_tokenizer(t.clone());
    let handle = processor.semantic_session();
    let p = handle.preview_tokens(&ids(&t, CALL)).unwrap();
    assert!(p.mapping_exact);
    assert!(handle.terminal().unwrap().is_none());
    let mut input = ids(&t, CALL)
        .into_iter()
        .map(|id| InferenceChunk::Token { token_id: id })
        .collect::<Vec<_>>();
    input.push(InferenceChunk::Finish {
        finish_reason: InferenceFinishReason::Stop,
    });
    let stream = processor.process(tokio_stream::iter(input));
    tokio::pin!(stream);
    let mut chunks = Vec::new();
    while let Some(chunk) = stream.next().await {
        chunks.push(chunk.unwrap());
    }
    assert_eq!(handle.terminal().unwrap(), p.terminal);
    assert!(matches!(
        chunks.last(),
        Some(OutputChunk::Finish {
            reason: super::FinishReason::ToolCalls,
            ..
        })
    ));
    assert!(!handle.preview_tokens(&[]).unwrap().mapping_exact);
}
