"""Requires the preview-capable native build, never falls back to another parser."""
import json
from pathlib import Path

import deepseek_recipe as d
import pytest

TOKENIZER = Path(__file__).resolve().parents[2] / "static/tokenizers/v41/tokenizer.json"
CALL = ('<｜DSML｜ calls>\n<｜DSML｜ invoke name="lookup">\n'
        '<｜DSML｜ parameter name="city" string="true">Paris</｜DSML｜ parameter>\n'
        '</｜DSML｜ invoke>\n</｜DSML｜ calls>')


def processor(stops=(), reasoning=False, json_mode=False):
    t = d.Tokenizer.from_file(str(TOKENIZER))
    options = d.ParsingOptions()
    options.stop_sequences = list(stops)
    options.parse_json_output = json_mode
    if reasoning:
        options.reasoning_initial_stage = d.ReasoningStage.Reasoning
    p = d.StreamProcessor(d.ChatCompletionChunkGenerator("preview", "v41", True, reasoning), options, t)
    assert hasattr(p, "preview_tokens"), "wrong native build: semantic API missing"
    return t, p


def fields(p):
    return (p.terminal_kind, p.completing_token_index, p.safe_token_count,
            p.source_start, p.source_end, p.mapping_exact, p.candidate_ids_processed, p.max_pending_ids)


@pytest.mark.parametrize("text,stops,reasoning,json_mode", [
    ("ordinary café🙂", (), False, False),
    (CALL, (), False, False),
    (CALL + "TAIL", (), False, False),
    ("thoughts</think>" + CALL, (), True, False),
    ("HALT NOT café🙂HALT NOWtail", ("HALT NOW",), False, False),
    ('```json\n{"x":"STOPtail"}\n```', ("STOP",), False, True),
])
def test_preview_never_changes_canonical_events(text, stops, reasoning, json_mode):
    t, p = processor(stops, reasoning, json_mode)
    _, reference = processor(stops, reasoning, json_mode)
    tokens = t.encode(text)
    actual_events, reference_events = [], []
    for index, token in enumerate(tokens):
        if p.finished:
            break
        before = p.semantic_terminal
        snapshot = p.semantic_snapshot()
        if before is None:
            first = p.preview_tokens(tokens[index:])
            assert fields(first) == fields(p.preview_tokens(tokens[index:]))
            assert first.mapping_exact
            assert p.semantic_snapshot() == snapshot
            assert p.semantic_terminal is None
        for out in p.push(d.InferenceChunk.token(token)):
            value = json.loads(out.to_json())
            value["created"] = 0
            actual_events.append(value)
        for out in reference.push(d.InferenceChunk.token(token)):
            value = json.loads(out.to_json())
            value["created"] = 0
            reference_events.append(value)
    for target, events in [(p, actual_events), (reference, reference_events)]:
        if not target.finished:
            for out in target.push(d.InferenceChunk.finish(d.InferenceFinishReason.Stop)):
                value = json.loads(out.to_json())
                value["created"] = 0
                events.append(value)
    assert actual_events == reference_events


def test_exact_dsml_terminal_is_not_stream_finished():
    t, p = processor()
    tokens = t.encode(CALL)
    for split in range(len(tokens)):
        _, fork = processor()
        for token in tokens[:split]:
            fork.push(d.InferenceChunk.token(token))
        result = fork.preview_tokens(tokens[split:])
        assert result.terminal_kind == "DSML_TOOL_CALL_BLOCK_END"
        assert result.safe_token_count == len(tokens) - split - 1
        assert result.completing_token_index == result.safe_token_count
        assert CALL.encode()[result.source_start:result.source_end] == '</｜DSML｜ calls>'.encode()
        assert fork.semantic_terminal is None
        for token in tokens[split:]:
            fork.push(d.InferenceChunk.token(token))
        assert fork.semantic_terminal.kind == result.terminal_kind
        inexact = fork.preview_tokens(tokens)
        assert not inexact.mapping_exact
        assert inexact.safe_token_count == 0
        assert not fork.finished
        fork.close()
    p.close()


def test_pending_canonical_unicode_ids_are_snapshotted():
    t, p = processor(("🙂",))
    tokens = t.encode("🙂")
    assert len(tokens) > 1
    p.push(d.InferenceChunk.token(tokens[0]))
    snapshot = p.semantic_snapshot()
    assert snapshot[1] == tokens[:1]
    assert snapshot[2] == 1
    result = p.preview_tokens(tokens[1:])
    assert p.semantic_snapshot() == snapshot
    assert result.terminal_kind == "STOP_SEQUENCE"
    assert result.completing_token_index == len(tokens) - 2
    assert p.semantic_terminal is None
    for token in tokens[1:]:
        p.push(d.InferenceChunk.token(token))
    assert p.semantic_terminal.kind == result.terminal_kind
    assert p.finished


def test_eof_probe_is_still_not_dsml_completion():
    t, p = processor()
    text = CALL[:CALL.rfind('</｜DSML｜ calls>')]
    result = p.preview_tokens(t.encode(text))
    assert result.terminal_kind is None
    for token in t.encode(text):
        p.push(d.InferenceChunk.token(token))
    assert p.semantic_terminal is None
    p.push(d.InferenceChunk.finish(d.InferenceFinishReason.Stop))
    assert p.semantic_terminal is None


def test_missing_tokenizer_and_closed_input_fail_closed():
    p = d.StreamProcessor(d.ChatCompletionChunkGenerator("x", "v41", False, False), d.ParsingOptions())
    with pytest.raises(RuntimeError):
        p.preview_tokens([1])
    p.close()
    with pytest.raises(RuntimeError):
        p.preview_tokens([1])
    with pytest.raises(RuntimeError):
        _ = p.semantic_terminal
