"""Canonical operator CLI for the ds41f release."""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any

from ds41f_mlx.config import load_runtime_config
from ds41f_mlx.release import load_release_manifest

ROOT = Path(__file__).resolve().parents[1]


def _run_module(module: str, args: list[str]) -> int:
    return subprocess.call([sys.executable, "-m", module, *args], cwd=ROOT)


def main(argv: list[str] | None = None) -> int:
    argv = sys.argv[1:] if argv is None else argv
    if not argv:
        from .operator_tui import main as tui_main
        return tui_main()
    parser = argparse.ArgumentParser(description="ds41f release operations")
    sub = parser.add_subparsers(dest="cmd", required=True)
    sub.add_parser("inspect", help="inspect release manifest, configuration and provenance")
    sub.add_parser("start", help="start the local runtime server (delegates to ds41f_mlx.serve)")
    sub.add_parser("quick", help="run quick operational qualification")
    sub.add_parser("accept", help="run one-command release acceptance")
    sub.add_parser("full", help="run explicit full qualification")
    for command in sub.choices.values():
        profiles = ['standard-off', 'mtp-singleton-v1']
        if command is sub.choices['start'] or command is sub.choices['inspect'] or command is sub.choices['accept']:
            profiles.append('mtp-serving-v1')
        command.add_argument('--profile', choices=profiles,
                             default='mtp-serving-v1' if 'mtp-serving-v1' in profiles else 'standard-off')
    args, rest = parser.parse_known_args(argv)

    if args.profile in ('mtp-singleton-v1', 'mtp-serving-v1'):
        if args.cmd == 'start':
            os.execv(sys.executable, [sys.executable, '-I', '-m', 'ds41f_mlx.serve', '--profile', args.profile, *rest])
        if args.cmd == 'accept':
            if args.profile == 'mtp-serving-v1':
                return subprocess.call([sys.executable, '-I', '-m', 'ds41f_mlx.production_acceptance', *rest])
            parser.error('historical singleton qualification belongs to the source/R1 evidence lane; use ordinary installed acceptance')
        if args.cmd != 'inspect':
            parser.error('MTP supports inspect/start/accept only')
        try:
            from .mtp_identity import config, inspect
            cfg = config(profile=args.profile)
            report = inspect(cfg)
            report['profile'] = report['serving_profile'] = args.profile
            if args.profile == 'mtp-serving-v1':
                from .serving.capacity import context_envelope, ORDINARY_BODY_BYTES, ORDINARY_OUTPUT_CEILING
                report['serving_limits'] = dict(context_tokens=context_envelope(cfg.checkpoint_path),
                                                output_tokens=ORDINARY_OUTPUT_CEILING, body_bytes=ORDINARY_BODY_BYTES)
            print(json.dumps(report, indent=2, sort_keys=True))
            return 0
        except (ValueError, OSError, ImportError) as exc:
            print(json.dumps({'status':'FAIL','profile':args.profile,'error':str(exc)}))
            return 2

    if args.cmd == "inspect":
        cfg = load_runtime_config(); cfg.apply_environment(); cfg.apply_import_paths()
        from .delivery import inspect as inspect_installed_off
        try:
            provenance = inspect_installed_off(cfg)
        except (ValueError, OSError, ImportError) as exc:
            provenance = {'status': 'FAIL', 'error': str(exc)}
        print(json.dumps({"schema":"ds41f.ops.inspect.v2", "status": provenance.get("status"), "release_manifest": load_release_manifest(), "admission": provenance}, indent=2, sort_keys=True))
        return 0 if provenance.get("status") in {"PASS", "WARNING"} else 2
    if args.cmd == "start":
        os.execv(sys.executable, [sys.executable, '-I', '-m', 'ds41f_mlx.serve', '--profile', args.profile, *rest])
    if (ROOT/'release/promotion.json').exists() and args.cmd in ('quick', 'full'):
        parser.error('Projected runtime qualification: use ds41f_mlx.reference --real-model, not historical development campaigns')
    if args.cmd == "quick":
        return _run_module("ds41f_mlx.qualify", ["--mode", "quick", *rest])
    if args.cmd == "accept":
        return _run_module("ds41f_mlx.release_acceptance", rest)
    if args.cmd == "full":
        return _run_module("ds41f_mlx.qualify", ["--mode", "full", *rest])
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
