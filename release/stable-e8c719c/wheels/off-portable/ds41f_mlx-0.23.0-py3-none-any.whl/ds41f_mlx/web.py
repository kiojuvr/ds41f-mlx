"""Single-user localhost application proxy. Runtime owns execution and state.

The browser owns ordinary application history; this process executes only declared
client tools. Stream disconnect propagates through the upstream HTTP connection.
"""
from __future__ import annotations

import argparse
import asyncio
import copy
import json
import ipaddress
import os
from time import monotonic
from pathlib import Path
from urllib.parse import quote

import httpx
from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, JSONResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles
from starlette.concurrency import run_in_threadpool
from starlette.middleware.trustedhost import TrustedHostMiddleware
from anyio import CancelScope

from ds41f_mlx.web_client import RuntimeClient, RuntimeHTTPError, StatefulToolChatClient
from ds41f_mlx.web_tools import registry_from_env, ToolError, TOOL_CALL_BYTES, TOOL_RESULT_BYTES, _json_dumps

STATIC_DIR = Path(__file__).with_name('web_static')
MAX_BODY = 100 * 1024 * 1024
MAX_LEDGER_BYTES = 256 * 1024 * 1024
LEDGER_BATCH_RESERVATION = 2 * (TOOL_RESULT_BYTES + TOOL_CALL_BYTES)


class WebStreamingResponse(StreamingResponse):
    async def __call__(self, scope, receive, send):
        try:
            await super().__call__(scope, receive, send)
        finally:
            with CancelScope(shield=True):
                await self.body_iterator.aclose()


PRIVATE_NETWORKS = tuple(ipaddress.ip_network(value) for value in (
    '10.0.0.0/8', '172.16.0.0/12', '192.168.0.0/16', 'fc00::/7',
))


def private_address(value: str) -> bool:
    """Explicit LAN ranges, not is_private (which includes reserved/test networks)."""
    try:
        address = ipaddress.ip_address(value)
    except ValueError:
        return False
    if isinstance(address, ipaddress.IPv6Address) and address.ipv4_mapped:
        address = address.ipv4_mapped
    return address.is_loopback or any(address.version == network.version and address in network for network in PRIVATE_NETWORKS)


def create_app(*, runtime_base_url: str | None = None, allow_private_lan: bool = False) -> FastAPI:
    runtime = RuntimeClient(runtime_base_url or os.environ.get('DS41F_RUNTIME_URL', 'http://127.0.0.1:8000'))
    tools = registry_from_env()
    document = tools.tools.get('document_pdf')
    if document and document.runtime_is_default:
        document.runtime = runtime  # respect --runtime-url, unless explicitly isolated
    app = FastAPI(title='ds41f-local-web-client', version='0.2.0')
    app.state.runtime = runtime
    app.state.tool_registry = tools
    # Bounded living-client tool effect ledger, NOT model/session authority.
    effects = {}
    effect_locks = {}
    owned = {}  # Runtime correlations, not ordinary history or an archive.
    app.state.owned_conversations = owned
    retirement_task = None
    idle_seconds = 600
    if not allow_private_lan:
        app.add_middleware(TrustedHostMiddleware, allowed_hosts=['127.0.0.1', 'localhost', '[::1]'])

    async def call(fn, *args, **kwargs):
        return await run_in_threadpool(fn, *args, **kwargs)

    async def body(request):
        chunks = bytearray()
        async for chunk in request.stream():
            if len(chunks) + len(chunk) > MAX_BODY:
                raise ToolError('application request exceeds 100 MiB')
            chunks.extend(chunk)
        value = json.loads(chunks or b'{}')
        if not isinstance(value, dict): raise ToolError('request must be an object')
        return value

    @app.middleware('http')
    async def local_boundary(request, call_next):
        if allow_private_lan:
            # Use the socket peer, never forwarded headers. Numeric LAN URLs only;
            # accepting arbitrary DNS names would reopen DNS-rebinding access.
            peer = request.client.host if request.client else ''
            try:
                host = request.url.hostname or ''
            except ValueError:
                host = ''
            if not private_address(peer):
                return JSONResponse(status_code=403, content={'error': {'message': 'private LAN peers only'}})
            if host != 'localhost' and not private_address(host):
                return JSONResponse(status_code=400, content={'error': {'message': 'private IP or localhost Host required'}})
        if request.method in ('POST', 'DELETE') and request.url.path.startswith('/api/'):
            origin = request.headers.get('origin')
            if (origin and origin != f'{request.url.scheme}://{request.url.netloc}') or request.headers.get('sec-fetch-site') == 'cross-site':
                return JSONResponse(status_code=403, content={'error': {'message': 'same-origin local API only'}})
            if request.method == 'POST' and request.headers.get('content-type', '').split(';')[0] != 'application/json':
                return JSONResponse(status_code=415, content={'error': {'message': 'application/json required'}})
            try:
                if (await call(runtime.health)).get('profile') == 'mtp-singleton-v1':
                    return JSONResponse(status_code=400, content={'error': {'message': 'Web application supports standard-OFF only'}})
            except RuntimeHTTPError as exc:
                return JSONResponse(status_code=502, content={'error': {'message': str(exc)}})
        response = await call_next(request)
        response.headers['Content-Security-Policy'] = "default-src 'self'; img-src 'self' data: blob:; object-src 'none'; base-uri 'none'; frame-ancestors 'none'"
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['Cache-Control'] = 'no-store'
        return response

    @app.exception_handler(RuntimeHTTPError)
    async def runtime_error(_, exc):
        return JSONResponse(status_code=502 if exc.status >= 500 else exc.status, content={'error': {'message': str(exc), 'runtime_status': exc.status}})

    @app.exception_handler(ToolError)
    async def tool_error(_, exc):
        return JSONResponse(status_code=400, content={'error': {'message': str(exc), 'type': 'tool_error', 'code': exc.code, 'effect_not_started': exc.code in {'resource_ceiling', 'tool_preflight_rejection'}}})

    @app.get('/')
    async def index(): return FileResponse(STATIC_DIR/'index.html')

    @app.get('/api/status')
    async def status():
        try: health = await call(runtime.health)
        except Exception as exc: health = {'status': 'unreachable', 'error': str(exc)}
        documents = None
        if document:
            try:
                vision_health = health if document.runtime is runtime else await call(document.runtime.health)
            except Exception:
                vision_health = {'status': 'unreachable'}
            documents = dict(architecture='retained-pdf-v1', historical_image_slots_used=0,
                             observation_request='bounded-stateless',
                             vision_available=vision_health.get('status') == 'ready' and vision_health.get('profile') == 'standard-off',
                             vision_profile=vision_health.get('profile'),
                             vision_notice='Scanned/figure observations require an existing standard-OFF Vision runtime. Production text-only limits are unchanged.')
        return JSONResponse(content={'runtime': health, 'runtime_base_url': runtime.base_url, 'tools': tools.declarations, 'documents': documents})

    @app.post('/api/documents')
    async def upload_document(request: Request):
        import base64
        from urllib.parse import quote
        from .web_tools import AcquiredResource
        from .web_pdf_worker import MAX_PDF_BYTES
        value = await body(request)
        name = value.get('name', 'document.pdf')
        encoded = value.get('data')
        if not isinstance(name, str) or not 1 <= len(name) <= 200 or not isinstance(encoded, str) or len(encoded) > 4 * ((MAX_PDF_BYTES + 2) // 3):
            raise ToolError('PDF upload requires a bounded filename and base64 bytes')
        try:
            name.encode('utf-8')
            data = base64.b64decode(encoded, validate=True)
        except (ValueError, UnicodeEncodeError) as exc:
            raise ToolError('invalid PDF upload bytes/filename encoding') from exc
        if len(data) > MAX_PDF_BYTES or not data.startswith(b'%PDF-'):
            raise ToolError('PDF upload must be PDF bytes within 64 MiB')
        document = tools.tools['document_pdf']
        uri = 'upload:///' + quote(name, safe='')
        artifact = await call(document.store.put_document, value.get('id'), AcquiredResource(data=data, url=uri, source_url=uri, content_type='application/pdf', truncated=False, redirects=0))
        # Publish receipt even if parser inspection fails. GET can reconcile.
        return JSONResponse(content=artifact.metadata())

    @app.get('/api/documents/{identity}')
    async def document_info(identity: str):
        document = tools.tools['document_pdf']
        artifact = await call(document.store.get, identity, 'pdf')
        try:
            result = await call(document.run, dict(artifact_id=identity, action='info'))
            return JSONResponse(content=result.display)
        except ToolError as exc:
            return JSONResponse(content=dict(artifact.metadata(), state='inspection_failed', error=str(exc)))

    @app.get('/api/documents/{identity}/pages/{page}')
    async def document_page(identity: str, page: int):
        document = tools.tools['document_pdf']
        artifact = await call(document.store.get, identity, 'pdf')
        result = await call(document.pdf.run, dict(artifact_id=identity, pages=[page], mode='text'))
        if result.display.get('error'):
            return JSONResponse(content=result.display)
        # UI-only raster: not appended to conversation or sent for inference.
        try:
            image_part, raster_identity, parser_policy = await call(document.raster, artifact, page)
            image, raster_error = image_part['image_url']['url'], None
        except ToolError as exc:
            image, raster_identity, parser_policy, raster_error = None, None, None, str(exc)
        return JSONResponse(content=dict(result.display, image=image, raster_identity=raster_identity,
                            parser_policy=parser_policy, raster_error=raster_error,
                            observation=await call(document.observation, artifact, page)))

    @app.get('/api/documents/{identity}/original')
    async def original_document(identity: str):
        artifact = await call(tools.tools['document_pdf'].store.get, identity, 'pdf')
        return Response(artifact.resource.data, media_type='application/pdf', headers={'Content-Disposition': 'attachment; filename="original.pdf"'})

    async def retire_owned(force=False):
        for sid, touched in list(owned.items()):
            if owned.get(sid) != touched:
                continue  # Renewed while another retirement awaited runtime.
            if not force and monotonic()-touched < idle_seconds:
                continue
            if effect_locks.get(sid) and effect_locks[sid].locked():
                continue  # In-flight effects must finish before ledger retirement.
            try:
                await call(runtime.close_session, sid)
            except RuntimeHTTPError as exc:
                if exc.status != 404:
                    continue  # Busy/uncertain retirement is not resource release.
            owned.pop(sid, None)
            effects.pop(sid, None)
            effect_locks.pop(sid, None)

    app.state.retire_owned = retire_owned

    @app.on_event('startup')
    async def start_retirement():
        nonlocal retirement_task
        async def sweep():
            while True:
                await asyncio.sleep(30)
                await retire_owned()
        retirement_task = asyncio.create_task(sweep())

    @app.on_event('shutdown')
    async def stop_retirement():
        if retirement_task:
            retirement_task.cancel()
            await asyncio.gather(retirement_task, return_exceptions=True)
        await retire_owned(force=True)  # Busy work remains protected by runtime.

    async def identities(request):
        ids = (await body(request)).get('ids')
        if (not isinstance(ids, list) or len(ids) > 32 or
                any(not isinstance(sid, str) or not 1 <= len(sid) <= 128 for sid in ids)):
            raise ToolError('bounded conversation identities required')
        return ids

    @app.post('/api/keepalive')
    async def keepalive(request: Request):
        alive = []
        for sid in await identities(request):
            if sid not in owned:
                continue
            owned[sid] = monotonic()
            try:
                await call(runtime.get_session, sid)  # Renew logical idle lease only.
                alive.append(sid)
            except RuntimeHTTPError:
                pass  # No reconstruction or automatic create.
        return JSONResponse(content={'alive': alive})

    @app.post('/api/release')
    async def release(request: Request):
        for sid in await identities(request):
            if sid in owned:
                owned[sid] = 0
        await retire_owned()
        return JSONResponse(content={'release_requested': True})

    @app.post('/api/session')
    async def create_session(request: Request):
        value = await body(request)
        await retire_owned()
        rec = await call(runtime.create_session, value.get('id'))
        owned[rec['id']] = monotonic()
        return JSONResponse(content=rec)

    @app.get('/api/session/{session_id}')
    async def get_session(session_id: str): return JSONResponse(content=await call(runtime.get_session, session_id))

    @app.delete('/api/session/{session_id}')
    async def close_session(session_id: str):
        try:
            record = await call(runtime.close_session, session_id)
        except RuntimeHTTPError as exc:
            if exc.status == 404:
                owned.pop(session_id, None)
                effects.pop(session_id, None)
                effect_locks.pop(session_id, None)
            raise
        owned.pop(session_id, None)
        effects.pop(session_id, None)
        effect_locks.pop(session_id, None)
        return JSONResponse(content=record)

    @app.post('/api/session/{session_id}/cancel')
    async def cancel(session_id: str, request: Request):
        return JSONResponse(content=await call(runtime.request, 'POST', f'/v1/sessions/{quote(session_id, safe="")}/cancel', await body(request)))

    @app.post('/api/budget')
    async def budget(request: Request):
        value = await body(request)
        sid = value.get('session_id')
        if not isinstance(sid, str) or not isinstance(value.get('request'), dict):
            raise ToolError('session_id and complete request required')
        result = await call(runtime.request, 'POST', f'/v1/sessions/{quote(sid, safe="")}/budget', value['request'])
        if result['request_count'] != value.get('expected_count'):
            raise ToolError('runtime/application frontier mismatch; reconcile before budget')
        return JSONResponse(content=result)

    @app.post('/api/stream')
    async def stream(request: Request):
        value = await body(request)
        sid = value.get('session_id')
        if not isinstance(sid, str) or not isinstance(value.get('request'), dict): raise ToolError('session_id and request are required')
        rec = await call(runtime.get_session, sid)
        if rec['request_count'] != value.get('expected_count') or rec['state'] not in ('empty', 'idle'):
            raise ToolError('runtime/application frontier mismatch or busy; reconcile first')
        upstream = dict(value['request'], stream=True, model='deepseek-v4.1-flash')
        # No retries, transcript surgery, image conversion or hidden tool loop.
        async def relay():
            try:
                async with httpx.AsyncClient(timeout=1800) as client:
                    async with client.stream('POST', runtime.base_url + f'/v1/sessions/{quote(sid, safe="")}/chat/completions', json=upstream, headers={'X-DS41F-Expected-Request-Count': str(value['expected_count']), 'X-DS41F-Application-Request-ID': str(value['application_id'])}) as response:
                        if response.status_code != 200:
                            raise RuntimeHTTPError(response.status_code, (await response.aread()).decode('utf-8', 'replace'))
                        request_id = response.headers['x-ds41f-request-id']
                        yield 'event: admitted\ndata: ' + json.dumps({'request_id': request_id}) + '\n\n'
                        async for chunk in response.aiter_bytes():
                            yield chunk
            except asyncio.CancelledError:
                raise  # context managers close upstream socket; runtime settles
            except Exception as exc:
                yield 'event: error\ndata: ' + json.dumps({'message': str(exc)}) + '\n\n'
        return WebStreamingResponse(relay(), media_type='text/event-stream', headers={'X-Accel-Buffering': 'no'})

    @app.get('/api/tools/result')
    async def observe_tool_result(session_id: str, request_count: int):
        rec = await call(runtime.get_session, session_id)
        entry = effects.get(session_id)
        identity = (request_count, (rec.get('last_turn') or {}).get('request_id'))
        result = entry['result'] if entry and entry['identity'] == identity and rec['request_count'] == request_count else None
        return JSONResponse(content={'result': result, 'observation_only': True})

    @app.post('/api/tools')
    async def execute_tools(request: Request):
        value = await body(request)
        sid, count = value.get('session_id'), value.get('request_count')
        if not isinstance(sid, str): raise ToolError('session_id required')
        if sid not in effect_locks:
            if len(effect_locks) >= 32: raise ToolError('tool ledger capacity reached; idle conversations retire automatically')
            effect_locks[sid] = asyncio.Lock()
        async with effect_locks[sid]:
            rec = await call(runtime.get_session, sid)
            owned[sid] = monotonic()
            turn = rec.get('last_turn') or {}
            cert = turn.get('reconstruction') or {}
            if rec['state'] != 'idle' or rec['request_count'] != count or not cert.get('executable_tools'):
                raise ToolError('tools require the settled executable canonical turn')
            calls = turn['response_json']['choices'][0]['message'].get('tool_calls') or []
            if not calls or len(_json_dumps(calls).encode('utf-8')) > TOOL_CALL_BYTES:
                raise ToolError('tool batch must be nonempty and within 1 MiB call serialization ceiling', code='resource_ceiling')
            identity = (count, turn['request_id'])
            entry = effects.get(sid)
            if entry is not None and entry['identity'] == identity:
                if entry['result'] is None: raise ToolError('tool effect outcome uncertain; automatic retry forbidden', code='uncertain_external_effect_outcome')
                return JSONResponse(content=entry['result'])
            # Invalid calls have no effect outcome to reserve/reconcile.
            try:
                await call(tools.validate_calls, calls)
            except ToolError as exc:
                raise ToolError(str(exc), code='tool_preflight_rejection') from exc
            ledger_used = sum(e.get('reserved_bytes', LEDGER_BATCH_RESERVATION) for key, e in effects.items() if key != sid)
            if ledger_used + LEDGER_BATCH_RESERVATION > MAX_LEDGER_BYTES:
                raise ToolError('aggregate tool ledger resource ceiling; wait for idle conversation retirement', code='resource_ceiling')
            entry = effects[sid] = {'identity': identity, 'result': None, 'reserved_bytes': LEDGER_BATCH_RESERVATION}  # reserve before effects
            messages, displays = await call(tools.execute_calls, calls, session_id=sid)
            # Publish actual effects before any budget fitting can fail. Never
            # leave a completed download/search as an uncertain/retryable effect.
            entry['source_results'] = copy.deepcopy({'messages': messages, 'results': displays})
            entry['result'] = {'messages': messages, 'results': displays, 'request_count': count}
            if isinstance(value.get('request'), dict):
                from ds41f_mlx.web_budget import fit_tool_results
                try:
                    messages, displays, budget = await call(fit_tool_results, runtime, sid, count, value['request'], messages, displays)
                    entry['result'].update(messages=messages, results=displays, capacity=budget)
                except (RuntimeHTTPError, ToolError) as error:
                    entry['result']['budget_error'] = str(error)
            entry['reserved_bytes'] = len(_json_dumps(entry['source_results']).encode('utf-8')) + len(_json_dumps(entry['result']).encode('utf-8'))
            return JSONResponse(content=entry['result'])

    @app.post('/api/session/{session_id}/persist')
    async def persist(session_id: str, request: Request):
        await body(request)
        return JSONResponse(content=await call(runtime.persist, session_id))

    @app.post('/api/session/restore')
    async def restore(request: Request):
        value = await body(request)
        if not value.get('artifact_path'): raise ToolError('artifact_path required')
        return JSONResponse(content=await call(runtime.restore, value['artifact_path'], value.get('id')))

    @app.post('/api/chat')
    async def legacy_chat(request: Request):
        value = await body(request)
        if not isinstance(value.get('message'), str) or not value['message'].strip(): raise ToolError('message required')
        result = await call(StatefulToolChatClient(runtime, tools).run_turn, session_id=value['session_id'],
            transcript=value.get('transcript') or [], user_message=value['message'],
            max_tokens=value.get('max_tokens', 'auto'), temperature=value.get('temperature'), generation_settings=value.get('generation_settings'), tools_enabled=bool(value.get('tools_enabled', True)))
        return JSONResponse(content=result.to_json())

    app.mount('/static', StaticFiles(directory=STATIC_DIR), name='static')
    return app


def main(argv=None):
    parser = argparse.ArgumentParser(description='Run the localhost ds41f Web application')
    parser.add_argument('--host', default=os.environ.get('DS41F_WEB_HOST', '127.0.0.1'))
    parser.add_argument('--port', type=int, default=int(os.environ.get('DS41F_WEB_PORT', '8080')))
    parser.add_argument('--runtime-url', default=os.environ.get('DS41F_RUNTIME_URL', 'http://127.0.0.1:8000'))
    parser.add_argument('--allow-private-lan', action='store_true', help='allow trusted private-LAN peers and numeric IP Hosts; no authentication or internet serving')
    parser.add_argument('--ssl-certfile', help='optional HTTPS certificate (trusted by the browsing PCs)')
    parser.add_argument('--ssl-keyfile', help='HTTPS private key; required with --ssl-certfile')
    args = parser.parse_args(argv)
    if bool(args.ssl_certfile) != bool(args.ssl_keyfile):
        parser.error('--ssl-certfile and --ssl-keyfile must be supplied together')
    if args.host not in ('127.0.0.1', 'localhost', '::1'):
        if not args.allow_private_lan:
            parser.error('non-loopback bind requires --allow-private-lan')
        if args.host not in ('0.0.0.0', '::') and not private_address(args.host):
            parser.error('bind must be loopback, a private IP, or a wildcard with --allow-private-lan')
    from .observability import Projection
    from .operator_control import Control, CHAT_PORT
    projection = Projection()
    try:
        control = Control(projection, CHAT_PORT)
    except OSError:
        parser.error('CONFLICT: chat control socket already in use')
    try:
        control.reserve_service(args.host, args.port)
        app = create_app(runtime_base_url=args.runtime_url, allow_private_lan=args.allow_private_lan)
        @app.on_event('startup')
        async def ready():
            from .operator_network import chat_endpoint
            projection.lifecycle('READY', chat_endpoint(args.host, args.port,
                allow_private_lan=args.allow_private_lan, tls=bool(args.ssl_certfile),
                runtime_url=args.runtime_url))
        control.run(app, host=args.host, port=args.port, proxy_headers=False,
                    ssl_certfile=args.ssl_certfile, ssl_keyfile=args.ssl_keyfile)
    finally:
        control.close()

if __name__ == '__main__': main()
