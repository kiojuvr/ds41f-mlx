"""Target-native source-clone provisioning; build inputs are repository authority."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[1]
SOURCES = ROOT / 'third_party/mtp'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def run(*args, env=None):
    subprocess.run([str(a) for a in args], check=True, env=env)


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--profile', choices=['standard-off', 'mtp-singleton-v1'], default='mtp-singleton-v1')
    p.add_argument('--glm-profile', choices=['native', 'portable'],
                   help='explicit execution distribution; no fallback')
    p.add_argument('--venv', type=Path, required=True)
    p.add_argument('--build-dir', type=Path, required=True)
    args = p.parse_args(argv)
    from .glm_profile import default_profile
    args.glm_profile = args.glm_profile or default_profile('mtp' if args.profile == 'mtp-singleton-v1' else 'standard-off')
    if platform.system() != 'Darwin' or platform.machine() != 'arm64':
        p.error('qualified setup requires Apple Silicon macOS')
    venv, build = args.venv.resolve(), args.build_dir.resolve()
    lock = json.loads((SOURCES/'sources.json').read_text())
    normal = json.loads((SOURCES/'normal-local.json').read_text())
    if args.profile == 'mtp-singleton-v1':
        lock['sources']['recipe'] = normal['recipe_source']
    build.mkdir(parents=True, exist_ok=True)
    for name, spec in lock['sources'].items():
        archive = SOURCES/spec['archive']
        if sha(archive) != spec['sha256']:
            raise ValueError('unapproved dependency source archive')
        target = build/name
        if target.exists():
            raise ValueError('build-dir must have no prior dependency source exports')
        target.mkdir()
        with tarfile.open(archive) as tar:
            tar.extractall(target, filter='data')
    if args.profile == 'mtp-singleton-v1':
        for label in ('compressed-growth', 'bit-exact-kernels', 'template-reuse', 'context-copy'):
            overlay = json.loads((SOURCES/f'{label}.json').read_text())
            patch = SOURCES/f'{label}.patch'
            if sha(patch) != overlay['patch_sha256']:
                raise ValueError(f'unapproved {label} patch')
            for name, identity in overlay['files'].items():
                path = build/'omlx/omlx'/name
                if (sha(path) if path.exists() else None) != identity['before']:
                    raise ValueError(f'{label} base drift: {name}')
            subprocess.run(['patch', '-p1', '-i', str(patch)], cwd=build/'omlx', check=True)
            for name, identity in overlay['files'].items():
                if sha(build/'omlx/omlx'/name) != identity['after']:
                    raise ValueError(f'{label} output drift: {name}')
    if venv.exists():
        raise ValueError('target venv must be absent; construct a fresh locked environment')
    run('uv', 'venv', '--python', '/opt/homebrew/opt/python@3.13/bin/python3.13', venv)
    python = venv/'bin/python'
    if subprocess.check_output([str(python),'-c','import platform; print(platform.python_version())'],text=True).strip() != '3.13.15':
        raise ValueError('qualified setup requires Python 3.13.15; recreate the target venv')
    requirements = SOURCES/('requirements-normal-local.lock' if args.profile == 'mtp-singleton-v1'
                            else 'requirements.lock')
    if args.profile == 'standard-off':
        # The source-export lock predates the independently qualified OFF
        # numerical distribution. Use its repository-owned versions, then let
        # the package builder verify exact bytes (never enroll local inventory).
        off = json.loads((SOURCES/'standard-off-dependencies.json').read_text())
        lines = requirements.read_text().splitlines()
        for name, version in off['versions'].items():
            matches = [i for i, line in enumerate(lines) if line.startswith(name+'==')]
            if len(matches) != 1:
                raise ValueError(f'ambiguous OFF dependency requirement: {name}')
            lines[matches[0]] = name+'=='+version
        requirements = build/'requirements-standard-off.lock'
        requirements.write_text('\n'.join(lines)+'\n')
    run('uv','pip','install','--python',python,'-r',requirements)
    env = dict(os.environ)
    for key in list(env):
        if key in ('DOCS_RS','PYTHONPATH','WEB_CONCURRENCY','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS',
                   'RUSTC','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','CARGO_BUILD_TARGET',
                   'CFLAGS','CXXFLAGS','LDFLAGS') or key.startswith(('DS41F_','OMLX_','UVICORN_','DYLD_')):
            env.pop(key, None)
    env.update(PKG_CONFIG_PATH='/opt/homebrew/opt/opencv@4/lib/pkgconfig',
               OpenCV_DIR='/opt/homebrew/opt/opencv@4/lib/cmake/opencv4',
               CMAKE_PREFIX_PATH='/opt/homebrew/opt/opencv@4',
               LIBCLANG_PATH='/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib',
               CARGO_TARGET_DIR=str(build/'cargo'))
    if subprocess.check_output(['pkg-config','--modversion','opencv4'],env=env,text=True).strip() != '4.14.0':
        raise ValueError('qualified native build requires OpenCV 4.14.0')
    if args.profile == 'standard-off':
        # Reuse the exact M45/M47 admitted artifact. A fresh same-source build
        # is path-sensitive and is not authorization to replace its resource pin.
        from .off_recipe import artifact_authority
        wheel, _ = artifact_authority()
        wheels = [wheel]
    else:
        # Obtain the exact M52R artifact, not a path-dependent substitute build.
        # Full patched sources/Cargo.lock and original toolchain provenance ship
        # alongside it. Runtime separates semantic payload from host ABI.
        wheel = SOURCES/normal['wheel']['file']
        if sha(wheel) != normal['wheel']['sha256']:
            raise ValueError('unapproved normal-local native wheel')
        wheels = [wheel]
    run('uv','pip','install','--reinstall','--no-deps','--python',python,wheels[0],build/'omlx')
    resource = venv/'share/ds41f-mtp/recipe/static/tokenizers/v41'
    resource.mkdir(parents=True, exist_ok=True)
    import shutil
    shutil.copy2(build/'recipe/static/tokenizers/v41/tokenizer.json',resource/'tokenizer.json')
    # Standard OFF uses the unchanged R1 attributed base source, not the MTP patches.
    if args.profile == 'standard-off':
        site = Path(subprocess.check_output([str(python), '-c', 'import sysconfig; print(sysconfig.get_paths()["purelib"])'], text=True).strip())
        shutil.rmtree(site/'omlx')
        with tarfile.open(ROOT/'reference/R1/off-source.tar.gz') as archive:
            archive.extractall(site, filter='data')
    site = Path(subprocess.check_output([str(python), '-c', 'import sysconfig; print(sysconfig.get_paths()["purelib"])'], text=True).strip())
    from .glm_profile import provision
    provision(site, args.glm_profile)
    package_args = ['--output', build/'runtime-wheels', '--glm-profile', args.glm_profile]
    if args.profile == 'standard-off':
        package_args += ['--profile', 'standard-off', '--recipe-wheel', wheels[0]]
    run(python, ROOT/'tools/build_execution_package.py', *package_args)
    runtime_wheels = list((build/'runtime-wheels').glob('ds41f_mlx-*.whl'))
    if len(runtime_wheels) != 1:
        raise ValueError('exactly one execution package required')
    run('uv','pip','install','--no-deps','--python',python,runtime_wheels[0])
    # No local seal: the built package carries publisher admission authority.
    subprocess.run([str(python), '-I', '-c',
                    'from ds41f_mlx.execution_identity import inspect_payload; inspect_payload()'],
                   check=True, env=env)
    print(f'Provisioned {venv}. Runtime needs neither donor checkouts nor build-dir.')


if __name__ == '__main__':
    main()
